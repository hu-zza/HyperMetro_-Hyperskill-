import java.util.Scanner;
import java.util.stream.IntStream;

public class Main {
  public static void main(String[] args) {
    try (var scanner = new Scanner(System.in)) {
      int nodeCount = scanner.nextInt();
      int[] parents = IntStream.generate(scanner::nextInt).limit(nodeCount).toArray();

      System.out.println(new BinaryTree().findHeight(parents, nodeCount));
    }
  }
}


// Java program to find height using parent array
class BinaryTree {

	// This function fills depth of i'th element in parent[]. The depth is
	// filled in depth[i].
	void fillDepth(int parent[], int i, int depth[]) {

		// If depth[i] is already filled
		if (depth[i] != 0) {
			return;
		}

		// If node at index i is root
		if (parent[i] == -1) {
			depth[i] = 1;
			return;
		}

		// If depth of parent is not evaluated before, then evaluate
		// depth of parent first
		if (depth[parent[i]] == 0) {
			fillDepth(parent, parent[i], depth);
		}

		// Depth of this node is depth of parent plus 1
		depth[i] = depth[parent[i]] + 1;
	}

	// This function returns height of binary tree represented by
	// parent array
	int findHeight(int parent[], int n) {

		// Create an array to store depth of all nodes/ and
		// initialize depth of every node as 0 (an invalid
		// value). Depth of root is 1
		int depth[] = new int[n];
		for (int i = 0; i < n; i++) {
			depth[i] = 0;
		}

		// fill depth of all nodes
		for (int i = 0; i < n; i++) {
			fillDepth(parent, i, depth);
		}

		// The height of binary tree is maximum of all depths.
		// Find the maximum value in depth[] and assign it to ht.
		int ht = depth[0];
		for (int i = 1; i < n; i++) {
			if (ht < depth[i]) {
				ht = depth[i];
			}
		}
		return ht;
	}
}

/* Wow.... o.O

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int k = Integer.parseInt(scanner.nextLine());
        int[] parents = new int[k];
        for (int i = 0; i < k; i++) {
            parents[i] = scanner.nextInt();
        }

        int max = 0;
        int[] maxDepth = new int[k];
        for (int i = 0; i < k; i++) {
            int node = i;
            int depth = 0;
            while (node != -1) {
                if (maxDepth[node] == 0) {
                    depth++;
                    node = parents[node];
                } else {
                    depth += maxDepth[node];
                    break;
                }
            }

            maxDepth[i] = depth;
            if (depth > max) {
                max = depth;
            }
        }

        System.out.println(max);
    }
}

 */