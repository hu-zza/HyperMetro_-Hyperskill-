import java.util.*;

public class Main {
    public static void main(String[] args) {
        try (var scanner = new Scanner(System.in)) {
            Map<Integer, ArrayList<Integer>> adjacencyMap = new HashMap<>();
            int nodeCount = scanner.nextInt();
            int parent;
            ArrayList<Integer> adjacencyList;

            for (int child = 0; child < nodeCount; child++) {
                parent = scanner.nextInt();
                adjacencyList = adjacencyMap.getOrDefault(parent, new ArrayList<>());
                adjacencyList.add(child);
                adjacencyMap.put(parent, adjacencyList);
            }

            int depth = 0;
            final HashSet<Integer> currentNodes = new HashSet<>(Set.of(-1));
            final HashSet<Integer> nextNodes = new HashSet<>();

            while (nodeCount != 0) {
                adjacencyMap.keySet().stream()
                    .filter(currentNodes::contains)
                    .forEach(e -> nextNodes.addAll(adjacencyMap.get(e)));
                nodeCount -= nextNodes.size();
                currentNodes.clear();
                currentNodes.addAll(nextNodes);
                nextNodes.clear();
                depth++;
            }
            System.out.println(depth);
        }
    }
}
