import java.util.Scanner;
import java.util.Arrays;

public class Main {
    private static final int[] CHILDREN = new int[100];
    
    public static void main(String[] args) {
        try (var scanner = new Scanner(System.in)) {
            int nodeCount = scanner.nextInt();
            
            for (int i = 0; i < nodeCount; i++) {
                CHILDREN[scanner.nextInt()]++;
                scanner.nextInt();
            }
            
            var result = Arrays.stream(CHILDREN).anyMatch(e -> e != 0 && e != 2);
            System.out.println(result ? "no" : "yes");
        }
    }
}
