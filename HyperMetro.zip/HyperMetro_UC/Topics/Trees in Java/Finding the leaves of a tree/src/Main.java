import java.util.*;

public class Main {    
    public static void main(String[] args) {
        Map<Integer, ArrayList<Integer>> adjacencyMap = new HashMap<>();
        try (var scanner = new Scanner(System.in)) {
            int edgeCount = scanner.nextInt();
            int parent;
            int child;
            ArrayList<Integer> adjacencyList;
            
            for (int i = 0; i < edgeCount; i++) {
                parent = scanner.nextInt();
                child = scanner.nextInt();
                adjacencyList = adjacencyMap.getOrDefault(parent, new ArrayList<>());
                adjacencyList.add(child);
                adjacencyMap.put(parent, adjacencyList);
            }
            
            int node;
            ArrayList<Integer> neighbours;
            Deque<Integer> currentQue = new ArrayDeque<>(List.of(0));
            Deque<Integer> nextQue = new ArrayDeque<>();
            LinkedHashSet<Integer> leaves = new LinkedHashSet<>();
            
            while (currentQue.size() != 0) {
                node = currentQue.poll();
                neighbours = adjacencyMap.get(node);
                if (neighbours == null || neighbours.isEmpty()) {
                    leaves.add(node);
                } else {
                    nextQue.addAll(neighbours);
                }   
                
                if (currentQue.size() == 0) {
                    currentQue.addAll(nextQue);
                    nextQue.clear();
                }
            }
            
            if (edgeCount == 0) {
                System.out.print("0");
            } else {
                System.out.println(leaves.size());
                leaves.stream().map(e -> e + " ").forEach(System.out::print);   
            }
        }   
    }
}
